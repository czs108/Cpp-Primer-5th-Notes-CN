Some programs read cin for their input.
Sample data files are in the data directory:

     File           Programs that use that input file
     ----           --------
   absInt           absInt
   accum            accum
   count-size       elimDups
   count-size       bind2
   count-size       newcount-size
   book_sales       avg_price
   book_sales       sortSI
   iostream_iter    accum4
   iostream_iter    equiv-istream
   iostream_iter    iostream_iter
   iostream_iter    ostreamIter2
   iostream_iter    use-istream-iter
   rcomma           rcomma
   reverse-iter     reverse-iter
   use_find         use_find

Programs not listed above print output and do
not read any input

