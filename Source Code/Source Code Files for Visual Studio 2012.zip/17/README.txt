Some programs read cin for their input.
Sample data files are in the data directory:

     File           Programs that use that input file
     ----           --------
   bits             bits      
   game             game
   no-skipws        no-skipws
   skipws           getc
   skipws           badgetc  
   skipws           getput
   skipws           skipws
   store1,store2,   
   store3,store4    findbook

Programs not listed above print output and do
not read any input

