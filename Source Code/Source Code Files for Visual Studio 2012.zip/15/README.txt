Some programs read cin for their input.
Sample data files are in the data directory:

     File           Programs that use that input file
     ----           --------
   storyDatafile    andQueryTest
   storyDatafile    and_orQueryTest
   storyDatafile    wordQueryTest
   two              andQueryTest
   three            and_orQueryTest  
   querymain        wordQueryTest

Programs not listed above print output and do
not read any input

