Some programs read cin for their input.
Sample data files are in the data directory:

     File           Programs that use that input file
     ----           --------
   add_item         add_item
   add_item         add_itemV2
   add_item         fileio
   sstream          sstream
   sstream          fileio (Note, fileio reads both add_item and sstream)

Programs not listed above print output and do
not read any input

