Some programs read cin for their input.
Sample data files are in the data directory:

     File           Programs that use that input file
     ----           --------
   book_sales       compareDef
   book_trans       multiset  
   Vecmainin        Vecmain

Programs not listed above print output and do
not read any input

