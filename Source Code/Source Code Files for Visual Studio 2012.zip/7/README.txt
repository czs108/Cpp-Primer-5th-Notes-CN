Some programs read cin for their input.
Sample data files are in the data directory:

     File           Programs that use that input file
     ----           --------
   book_sales       avg_price     
   add_item         add_item

Programs not listed above print output and do
not read any input

